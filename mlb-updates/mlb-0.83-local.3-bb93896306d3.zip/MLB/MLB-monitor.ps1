﻿param([switch]$LibraryOnly)
$ErrorActionPreference = 'Stop'
function Test-ErrorText([string]$Text) {
    return $Text -match '(?i)\berror\b|\bexception\b|오류|에러|작동이 중지'
}
function Save-Incident($Root, $Ring, $Kind, $Details, $ProcessId) {
    $folder = Join-Path $Root ((Get-Date -Format 'yyyy-MM-dd_HH-mm-ss_fff') + '_' + $Kind + '_' + [guid]::NewGuid().ToString('N').Substring(0,6))
    New-Item -ItemType Directory -Path $folder -Force | Out-Null
    @("Time: $(Get-Date -Format o)", "Process: $ProcessId", "Type: $Kind", $Details) | Set-Content -LiteralPath (Join-Path $folder 'details.txt') -Encoding UTF8
    if (Test-Path -LiteralPath $Ring) { Copy-Item -LiteralPath $Ring -Destination (Join-Path $folder 'recent') -Recurse }
    return $folder
}
if ($LibraryOnly) { return }
$root = Join-Path $PSScriptRoot '오류기록'
$ring = Join-Path $root '최근화면'
New-Item -ItemType Directory -Path $ring -Force | Out-Null
$mutex = New-Object Threading.Mutex($false, 'Local\MLB_Error_Recorder')
if (-not $mutex.WaitOne(0)) { Write-Host 'Recorder already running.'; exit }
try {
    Add-Type -AssemblyName System.Windows.Forms, System.Drawing
    Add-Type @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class MlbWindows {
 public delegate bool Callback(IntPtr h, IntPtr l);
 [DllImport("user32.dll")] static extern bool EnumWindows(Callback cb, IntPtr l);
 [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr h, Callback cb, IntPtr l);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder b, int n);
 [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
 static string Text(IntPtr h) { var b=new StringBuilder(8192); GetWindowText(h,b,b.Capacity); return b.ToString(); }
 public static string[] Read(uint pid) {
  var list=new List<string>();
  EnumWindows((h,l)=>{ uint p; GetWindowThreadProcessId(h,out p);
   if(p==pid && IsWindowVisible(h)) { var b=new StringBuilder(Text(h));
    EnumChildWindows(h,(c,x)=>{b.AppendLine(Text(c)); return true;},IntPtr.Zero);
    list.Add(b.ToString()); } return true;},IntPtr.Zero);
  return list.ToArray();
 }
}
'@
    [void][MlbWindows]::SetProcessDPIAware()
    function Save-Screen($Path) {
        $bounds = [Windows.Forms.SystemInformation]::VirtualScreen
        $bitmap = New-Object Drawing.Bitmap($bounds.Width, $bounds.Height)
        $graphics = [Drawing.Graphics]::FromImage($bitmap)
        try {
            $graphics.CopyFromScreen($bounds.Left, $bounds.Top, 0, 0, $bounds.Size)
            $bitmap.Save($Path, [Drawing.Imaging.ImageFormat]::Png)
        } finally { $graphics.Dispose(); $bitmap.Dispose() }
    }
    $exe = Join-Path $PSScriptRoot 'MLB.exe'
    $existing = @(Get-Process -Name MLB -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $exe } catch { $false } })
    if ($existing.Count -gt 0) { $target = $existing[0] }
    else { $target = Start-Process -FilePath $exe -WorkingDirectory $PSScriptRoot -PassThru }
    Write-Host 'MLB recorder active. Keep this window open. Ctrl+C stops recording.'
    $seen = @{}
    $slot = 0
    $nextFrame = [datetime]::MinValue
    while ($true) {
        $target.Refresh()
        if ($target.HasExited) {
            $folder = Save-Incident $root $ring 'exit' "Exit code: $($target.ExitCode). Normal/manual exits are also recorded; this does not prove a crash." $target.Id
            try { Save-Screen (Join-Path $folder 'screen.png') } catch { $_ | Out-String | Add-Content (Join-Path $folder 'details.txt') }
            break
        }
        if ((Get-Date) -ge $nextFrame) {
            try { Save-Screen (Join-Path $ring ('frame-{0:00}.png' -f $slot)) } catch { $_ | Out-String | Set-Content (Join-Path $root 'capture-failure.txt') }
            $slot = ($slot + 1) % 12
            $nextFrame = (Get-Date).AddSeconds(10)
        }
        foreach ($windowText in [MlbWindows]::Read([uint32]$target.Id)) {
            if ((Test-ErrorText $windowText) -and -not $seen.ContainsKey($windowText)) {
                $folder = Save-Incident $root $ring 'dialog' $windowText $target.Id
                try { Save-Screen (Join-Path $folder 'screen.png') } catch { $_ | Out-String | Add-Content (Join-Path $folder 'details.txt') }
                $seen[$windowText] = $true
            }
        }
        Start-Sleep -Milliseconds 500
    }
} catch {
    $_ | Out-String | Set-Content -LiteralPath (Join-Path $root 'recorder-failure.txt') -Encoding UTF8
    Write-Host $_
    Read-Host 'Recorder failed. Press Enter to close'
} finally {
    $mutex.ReleaseMutex()
    $mutex.Dispose()
}
