﻿$ErrorActionPreference = 'Stop'
$config = Join-Path $PSScriptRoot 'MLB-update.json'
$existing = ''
if (Test-Path -LiteralPath $config) { $existing = (Get-Content -LiteralPath $config -Raw -Encoding UTF8 | ConvertFrom-Json).manifest }
Write-Host ('Update address: ' + $existing)
$address = Read-Host 'HTTPS update.json URL (Enter keeps current address)'
if (-not $address) { $address=$existing }
if ($address -notmatch '^https://') { throw 'A valid HTTPS update address is required.' }
@{manifest=$address} | ConvertTo-Json | Set-Content -LiteralPath $config -Encoding UTF8
$token = Read-Host 'Private repository token (leave empty for public repository)' -AsSecureString
if ($token.Length -gt 0) { $token | ConvertFrom-SecureString | Set-Content -LiteralPath (Join-Path $PSScriptRoot '.update-token.xml') -Encoding ASCII }
Write-Host 'Saved. This PC only. Do not share .update-token.xml.'
Read-Host 'Press Enter to close'
