﻿param([switch]$LibraryOnly,[switch]$Launch)
$ErrorActionPreference = 'Stop'

function Get-MlbResource([string]$Source,[string]$Destination,[string]$Token = '',[switch]$Package) {
    $uri = $null
    if ([Uri]::TryCreate($Source,[UriKind]::Absolute,[ref]$uri) -and $uri.Scheme -eq 'https') {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $headers = @{'User-Agent'='MLB-Updater/1';'Cache-Control'='no-cache'}
        if ($Package) { $headers['Accept']='application/octet-stream' }
        elseif ($uri.Host -eq 'api.github.com') { $headers['Accept']='application/vnd.github.raw+json' }
        else { $headers['Accept']='application/json' }
        if ($Token) { $headers['Authorization']='Bearer ' + $Token }
        Invoke-WebRequest -Uri $Source -Headers $headers -UseBasicParsing -OutFile $Destination -TimeoutSec 60 | Out-Null
    } elseif ([IO.Path]::IsPathRooted($Source) -and $Source -notmatch '^https?:') {
        Copy-Item -LiteralPath $Source -Destination $Destination -ErrorAction Stop
    } else { throw 'The update source must be HTTPS or an absolute local/shared path.' }
}
function Test-MlbBusy([string]$Root) {
    $exe = [IO.Path]::GetFullPath((Join-Path $Root 'MLB.exe'))
    foreach ($process in @(Get-Process -Name MLB -ErrorAction SilentlyContinue)) {
        try { if (-not $process.Path -or $process.Path -eq $exe) { return $true } }
        catch { return $true }
    }
    return $false
}
function Test-MlbReleasePath([string]$RelativePath) {
    if ($RelativePath -match '(^|[\\/])\.\.([\\/]|$)|:|^[/\\]' -or $RelativePath.Contains('\')) { return $false }
    if ($RelativePath -match '^assets/[a-z0-9-]+\.png$') { return $true }
    return $RelativePath -in @('MLB.exe','MLB-monitor.ps1','MLB-updater.ps1','MLB-자동기록으로실행.cmd','MLB-업데이트설정.ps1','MLB-업데이트설정.cmd','version.txt','사용방법.txt','manifest.json')
}
function Expand-MlbRelease([string]$Archive,[string]$Stage) {
    Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
    $zip = [IO.Compression.ZipFile]::OpenRead($Archive)
    try {
        $total = 0L
        $seen = @{}
        foreach ($entry in $zip.Entries) {
            if ($entry.FullName -eq 'MLB/' -or $entry.FullName -eq 'MLB/오류기록/' -or $entry.FullName -eq 'MLB/assets/') { continue }
            if (-not $entry.FullName.StartsWith('MLB/')) { throw 'Invalid package root.' }
            $relative = $entry.FullName.Substring(4)
            if (-not (Test-MlbReleasePath $relative) -or $seen.ContainsKey($relative)) { throw 'Unexpected or repeated package path.' }
            $seen[$relative] = $true
            $total += $entry.Length
            if ($total -gt 100MB -or $entry.Length -gt 50MB) { throw 'Update package is too large.' }
        }
        foreach ($entry in $zip.Entries) {
            if ($entry.FullName.EndsWith('/')) { continue }
            $relative = $entry.FullName.Substring(4)
            $destination = Join-Path $Stage $relative
            New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$destination,$false)
        }
    } finally { $zip.Dispose() }
    $manifest = Get-Content -LiteralPath (Join-Path $Stage 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $properties = @($manifest.files.PSObject.Properties)
    if (-not $properties.Count -or -not ($properties.Name -contains 'MLB.exe')) { throw 'Package file manifest missing.' }
    foreach ($property in $properties) {
        if (-not (Test-MlbReleasePath $property.Name) -or $property.Value -notmatch '^[0-9a-fA-F]{64}$') { throw 'Invalid file manifest.' }
        if ((Get-FileHash -LiteralPath (Join-Path $Stage $property.Name) -Algorithm SHA256).Hash -ne $property.Value) { throw 'Package file hash mismatch.' }
    }
    foreach ($file in Get-ChildItem -LiteralPath $Stage -Recurse -File) {
        $relative = $file.FullName.Substring($Stage.TrimEnd('\').Length+1).Replace('\','/')
        if ($relative -ne 'manifest.json' -and -not ($properties.Name -contains $relative)) { throw 'Unlisted package file.' }
    }
    return $manifest
}
function Invoke-MlbUpdate([string]$Root,[string]$Feed,[string]$Token = '') {
    $Root = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    $changed = @()
    $job = $null
    $mutexName = 'Local\MLB_Update_' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Root)).Replace('/','_').Replace('+','_')
    $mutex = New-Object Threading.Mutex($false,$mutexName)
    $ownsMutex = $false
    try {
        $ownsMutex = $mutex.WaitOne(0)
        if (-not $ownsMutex) { return @{status='deferred';reason='another updater is running'} }
        if (-not $Feed) { return @{status='not_configured'} }
        $job = Join-Path (Join-Path $Root '.update') ([guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $job -Force | Out-Null
        $feedFile = Join-Path $job 'update.json'
        Get-MlbResource $Feed $feedFile $Token
        $release = Get-Content -LiteralPath $feedFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($release.schema -ne 1 -or $release.release -notmatch '^\d+$' -or $release.sha256 -notmatch '^[a-fA-F0-9]{64}$') { throw 'Invalid release descriptor.' }
        $installedFile = Join-Path $Root 'update-installed.json'
        if (Test-Path -LiteralPath $installedFile) {
            $installed = Get-Content -LiteralPath $installedFile -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([long]$installed.release -gt [long]$release.release) { return @{status='current';reason='older server release ignored'} }
            if ([long]$installed.release -eq [long]$release.release -and $installed.sha256 -eq $release.sha256) { return @{status='current'} }
        }
        if (Test-MlbBusy $Root) { return @{status='deferred';reason='MLB is running; update will be checked next launch'} }
        $packageSource = [string]$release.package
        if ($packageSource -notmatch '^https://' -and -not [IO.Path]::IsPathRooted($packageSource)) {
            if ($packageSource -match '[/\\:]|^\.') { throw 'Invalid relative package location.' }
            if ($Feed -match '^https://') { $packageSource = [Uri]::new([Uri]$Feed,$packageSource).AbsoluteUri }
            else { $packageSource = Join-Path (Split-Path -Parent $Feed) $packageSource }
        }
        # A private-repository credential must never be sent to an unrelated host.
        $packageToken = $Token
        if ($Feed -match '^https://' -and $packageSource -match '^https://' -and ([Uri]$Feed).Host -ne ([Uri]$packageSource).Host) { $packageToken = '' }
        $archive = Join-Path $job 'release.zip'
        Get-MlbResource $packageSource $archive $packageToken -Package
        if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne $release.sha256) { throw 'Archive hash mismatch.' }
        $stage = Join-Path $job 'stage'
        New-Item -ItemType Directory -Path $stage -Force | Out-Null
        $manifest = Expand-MlbRelease $archive $stage
        if ($manifest.version -ne $release.version) { throw 'Release version mismatch.' }
        if (Test-MlbBusy $Root) { return @{status='deferred';reason='MLB started during download'} }
        $backup = Join-Path $job 'backup'
        $files = @(Get-ChildItem -LiteralPath $stage -Recurse -File)
        foreach ($file in $files) {
            $relative = $file.FullName.Substring($stage.Length+1)
            $destination = Join-Path $Root $relative
            $saved = Join-Path $backup $relative
            $existed = Test-Path -LiteralPath $destination
            if ($existed) {
                New-Item -ItemType Directory -Path (Split-Path -Parent $saved) -Force | Out-Null
                Copy-Item -LiteralPath $destination -Destination $saved -ErrorAction Stop
            }
            $changed += @{destination=$destination;backup=$saved;existed=$existed}
            New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
            Copy-Item -LiteralPath $file.FullName -Destination $destination -Force -ErrorAction Stop
            if ((Get-FileHash -LiteralPath $file.FullName).Hash -ne (Get-FileHash -LiteralPath $destination).Hash) { throw 'Installed file hash mismatch.' }
        }
        @{release=$release.release;version=$release.version;sha256=$release.sha256;installed_utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath $installedFile -Encoding UTF8
        return @{status='updated';version=$release.version}
    } catch {
        $rollbackFailed = $false
        for ($index=$changed.Count-1; $index -ge 0; $index--) {
            $item = $changed[$index]
            try {
                if ($item.existed) { Copy-Item -LiteralPath $item.backup -Destination $item.destination -Force -ErrorAction Stop }
                elseif (Test-Path -LiteralPath $item.destination) { Remove-Item -LiteralPath $item.destination -Force -ErrorAction Stop }
            } catch { $rollbackFailed=$true }
        }
        return @{status='failed';reason=$_.Exception.GetType().Name;rollback_failed=$rollbackFailed}
    } finally {
        if ($ownsMutex) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
        # Backups are retained for rollback/review. Remove only unneeded downloaded ZIP bytes.
        if ($job -and (Test-Path -LiteralPath (Join-Path $job 'release.zip'))) { Remove-Item -LiteralPath (Join-Path $job 'release.zip') -Force -ErrorAction SilentlyContinue }
    }
}
if ($LibraryOnly) { return }
$root = $PSScriptRoot
$configPath = Join-Path $root 'MLB-update.json'
$feed = 'https://raw.githubusercontent.com/Rasytal/mabinogi-market/main/mlb-updates/mlb-latest.json'
$token = ''
try {
    if (Test-Path -LiteralPath $configPath) { $feed = (Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json).manifest }
    $tokenFile = Join-Path $root '.update-token.xml'
    if (Test-Path -LiteralPath $tokenFile) {
        $secure = Get-Content -LiteralPath $tokenFile -Raw | ConvertTo-SecureString
        $token = (New-Object Net.NetworkCredential('',$secure)).Password
    }
    $result = Invoke-MlbUpdate -Root $root -Feed $feed -Token $token
} catch { $result = @{status='failed';reason=$_.Exception.GetType().Name} }
Write-Host ('MLB update: ' + $result.status)
@{time=[DateTime]::UtcNow.ToString('o');status=$result.status;reason=$result.reason} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $root 'update-status.json') -Encoding UTF8
if ($result.rollback_failed) { throw 'Update rollback failed. Restore the .update backup before launching.' }
if ($Launch) { & (Join-Path $root 'MLB-monitor.ps1') }
