﻿param([switch]$LibraryOnly)
$ErrorActionPreference = 'Stop'
# MLB 0.83-local.115 recorder + infinite-mode auto-restart supervisor.
# Recording behaviour is unchanged. Added: when infinite mode hits an error dialog or the
# MLB watchdog requests a restart, MLB is closed, the updater runs, and MLB is relaunched
# with /InfiniteRestart so the saved character/mode resumes. Loop guard stops repeated restarts.
function Test-ErrorText([string]$Text) {
    return $Text -match '(?i)\berror\b|\bexception\b|오류|에러|작동이 중지'
}
function Save-Incident($Root, $Ring, $Kind, $Details, $ProcessId, [switch]$WithRecent) {
    $folder = Join-Path $Root ((Get-Date -Format 'yyyy-MM-dd_HH-mm-ss_fff') + '_' + $Kind + '_' + [guid]::NewGuid().ToString('N').Substring(0,6))
    New-Item -ItemType Directory -Path $folder -Force | Out-Null
    @("Time: $(Get-Date -Format o)", "Process: $ProcessId", "Type: $Kind", $Details) | Set-Content -LiteralPath (Join-Path $folder 'details.txt') -Encoding UTF8
    # Disk saving: the ~2 minutes of recent frames are kept only for errors/auto-restarts, not every normal exit.
    if ($WithRecent -and (Test-Path -LiteralPath $Ring)) { Copy-Item -LiteralPath $Ring -Destination (Join-Path $folder 'recent') -Recurse }
    return $folder
}
function Get-OldIncidentNames([string[]]$Names, [datetime]$Now, [int]$KeepHours = 24, [int]$KeepMax = 20) {
    # 0.83-local.113: only the newest records stay - the last $KeepHours hours, at most $KeepMax folders.
    # 최근화면 and undated files (auto-restart-history.json) are never touched.
    $dated = @($Names | Where-Object { $_ -match '^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}' } | Sort-Object -Descending)
    $limit = $Now.AddHours(-$KeepHours).ToString('yyyy-MM-dd_HH-mm-ss')
    $old = @()
    for ($i = 0; $i -lt $dated.Count; $i++) {
        if ($i -ge $KeepMax -or $dated[$i].Substring(0,19) -lt $limit) { $old += $dated[$i] }
    }
    return $old
}
function Remove-OldIncidents([string]$Root, [int]$KeepHours = 24, [int]$KeepMax = 20) {
    try {
        $names = @(Get-ChildItem -LiteralPath $Root -Directory | ForEach-Object { $_.Name })
        foreach ($name in (Get-OldIncidentNames $names (Get-Date) $KeepHours $KeepMax)) { Remove-Item -LiteralPath (Join-Path $Root $name) -Recurse -Force -ErrorAction SilentlyContinue }
    } catch {}
}
function Test-LocalUpdatePending($Pending, [string]$CurrentVersion) {
    # A fix prepared on this PC (MLB-local-update.json) is installed once, before MLB starts.
    if (-not $Pending -or $Pending.done) { return $false }
    if (-not $Pending.version -or -not $Pending.installer -or -not $Pending.python) { return $false }
    return ([string]$Pending.version -ne $CurrentVersion)
}
function Get-RestartKey([string]$Reason) {
    # Digits (minutes, counters, times) change between otherwise identical failures.
    return (($Reason -replace '\d+','#') -replace '\s+',' ').Trim()
}
function Test-PlannedRestart([string]$Reason) {
    return $Reason -match '판 완료'
}
function Test-RestartAllowed($History, [string]$Kind, [string]$Reason, [string]$Version, [datetime]$NowUtc) {
    # Returns '' when allowed, otherwise the reason the restart is refused.
    if (Test-PlannedRestart $Reason) { return '' }
    $window = $NowUtc.AddMinutes(-30)
    $recent = @($History | Where-Object { -not $_.planned -and [datetime]::Parse($_.utc).ToUniversalTime() -ge $window })
    if ($recent.Count -ge 3) { return '30분 안에 자동 재시작 3회 초과' }
    $last = @($History | Where-Object { -not $_.planned }) | Select-Object -Last 1
    if ($last -and [datetime]::Parse($last.utc).ToUniversalTime() -ge $window -and $last.version -eq $Version -and $last.key -eq (Get-RestartKey $Reason)) {
        return '같은 버전에서 같은 오류 2회 연속'
    }
    return ''
}
function Test-SnapshotFresh([string]$Updated, [datetime]$NowUtc, [int]$MaxSeconds = 90) {
    $parsed = [datetime]::MinValue
    if (-not [datetime]::TryParseExact($Updated,'yyyyMMddHHmmss',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]'AssumeUniversal,AdjustToUniversal',[ref]$parsed)) { return $false }
    $age = ($NowUtc - $parsed).TotalSeconds
    return ($age -ge -30 -and $age -le $MaxSeconds)
}
if ($LibraryOnly) { return }

$identity = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $identity.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    # MLB.exe requires administrator rights. Elevating the recorder once lets it restart MLB without a UAC prompt each time.
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -WorkingDirectory $PSScriptRoot -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $PSCommandPath + '"')) | Out-Null
    } catch {
        Write-Host '관리자 권한이 거부되어 MLB를 시작하지 않았습니다. 다시 실행해 [예]를 눌러주세요.'
        Read-Host 'Enter를 누르면 닫힙니다'
    }
    exit
}

$root = Join-Path $PSScriptRoot '오류기록'
$ring = Join-Path $root '최근화면'
New-Item -ItemType Directory -Path $ring -Force | Out-Null
$mutex = New-Object Threading.Mutex($false, 'Local\MLB_Error_Recorder')
if (-not $mutex.WaitOne(0)) {
    Write-Host 'Recorder already running.'
    # MLB.exe hands its start to this script; never leave the user with nothing running.
    $mlbExe = Join-Path $PSScriptRoot 'MLB.exe'
    $running = @(Get-Process -Name MLB -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $mlbExe } catch { $true } })
    if ($running.Count -eq 0) { Start-Process -FilePath $mlbExe -ArgumentList '/Launched' -WorkingDirectory $PSScriptRoot | Out-Null }
    exit
}
$supervisor = $null
try {
    # MLB 0.83-local.75+ checks this name before handing its restart to the recorder.
    $supervisor = New-Object Threading.Mutex($false, 'Local\MLB_Restart_Supervisor')
    Add-Type -AssemblyName System.Windows.Forms, System.Drawing
    Add-Type @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class MlbWindows {
 public delegate bool Callback(IntPtr h, IntPtr l);
 [DllImport("user32.dll")] static extern bool EnumWindows(Callback cb, IntPtr l);
 [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr h, Callback cb, IntPtr l);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder b, int n);
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder b, int n);
 [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
 static string Text(IntPtr h) { var b=new StringBuilder(8192); GetWindowText(h,b,b.Capacity); return b.ToString(); }
 static string Cls(IntPtr h) { var b=new StringBuilder(256); GetClassName(h,b,b.Capacity); return b.ToString(); }
 static string[] Collect(uint pid, bool dialogsOnly) {
  var list=new List<string>();
  EnumWindows((h,l)=>{ uint p; GetWindowThreadProcessId(h,out p);
   if(p==pid && IsWindowVisible(h) && (!dialogsOnly || Cls(h)=="#32770")) { var b=new StringBuilder(Text(h));
    EnumChildWindows(h,(c,x)=>{b.AppendLine(Text(c)); return true;},IntPtr.Zero);
    list.Add(b.ToString()); } return true;},IntPtr.Zero);
  return list.ToArray();
 }
 public static string[] Read(uint pid) { return Collect(pid,false); }
 // Message boxes and AutoHotkey error dialogs only (class #32770); the MLB main window is excluded.
 public static string[] ReadDialogs(uint pid) { return Collect(pid,true); }
}
public class MlbRect {
 [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
 [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
 [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
 public static int[] Get(IntPtr h) { RECT r; if (h==IntPtr.Zero || IsIconic(h) || !GetWindowRect(h,out r)) return null; return new int[]{r.Left,r.Top,r.Right-r.Left,r.Bottom-r.Top}; }
}
public class MlbIni {
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern uint GetPrivateProfileString(string s, string k, string d, StringBuilder r, uint n, string f);
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] public static extern bool WritePrivateProfileString(string s, string k, string v, string f);
 public static string Read(string f, string s, string k) { var b=new StringBuilder(4096); GetPrivateProfileString(s,k,"",b,(uint)b.Capacity,f); return b.ToString(); }
}
'@
    [void][MlbWindows]::SetProcessDPIAware()
    $jpegCodec = [Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' } | Select-Object -First 1
    function Save-Screen($Path) {
        # Disk saving: capture only the game window (falls back to the whole screen) and store JPEG instead of PNG.
        $rect = $null
        $game = Get-Process -Name MabinogiMobile -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne [IntPtr]::Zero } | Select-Object -First 1
        if ($game) { $rect = [MlbRect]::Get($game.MainWindowHandle) }
        if ($rect -and $rect[2] -ge 200 -and $rect[3] -ge 200) { $left=$rect[0]; $top=$rect[1]; $width=$rect[2]; $height=$rect[3] }
        else { $b = [Windows.Forms.SystemInformation]::VirtualScreen; $left=$b.Left; $top=$b.Top; $width=$b.Width; $height=$b.Height }
        $bitmap = New-Object Drawing.Bitmap($width, $height)
        $graphics = [Drawing.Graphics]::FromImage($bitmap)
        try {
            $graphics.CopyFromScreen($left, $top, 0, 0, (New-Object Drawing.Size($width, $height)))
            $quality = New-Object Drawing.Imaging.EncoderParameters(1)
            $quality.Param[0] = New-Object Drawing.Imaging.EncoderParameter([Drawing.Imaging.Encoder]::Quality, [long]70)
            $bitmap.Save([IO.Path]::ChangeExtension($Path,'.jpg'), $jpegCodec, $quality)
        } finally { $graphics.Dispose(); $bitmap.Dispose() }
    }
    # Old PNG frames from earlier versions and records older than 3 days are cleared at start, then hourly.
    Get-ChildItem -LiteralPath $ring -Filter '*.png' -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    Remove-OldIncidents $root 24 20
    $nextCleanup = (Get-Date).AddHours(1)
    $temp = [IO.Path]::GetTempPath()
    $stateIni = Join-Path $temp 'MLB_InfiniteRestart_MLB.exe.ini'
    $snapshotIni = Join-Path $temp 'MLB_InfiniteResume_MLB.exe.ini'
    $requestIni = Join-Path $temp 'MLB_RestartRequest_MLB.exe.ini'
    $historyFile = Join-Path $root 'auto-restart-history.json'
    function Get-MlbVersion { try { return (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'version.txt') -Raw).Trim() } catch { return 'unknown' } }
    function Get-History {
        # Windows PowerShell 5.1 returns a JSON array as one object; piping it again yields the entries.
        try { if (Test-Path -LiteralPath $historyFile) { $data = Get-Content -LiteralPath $historyFile -Raw -Encoding UTF8 | ConvertFrom-Json; return @($data | ForEach-Object { $_ }) } } catch {}
        return @()
    }
    function Send-MlbPush([string]$Title, [string]$Message) {
        # Same Pushover account MLB already uses (MLB settings first, then the private defaults).
        $poIni = Join-Path $temp 'MabiMacros\pushover.ini'
        $token = [MlbIni]::Read($poIni,'pushover','token'); $user = [MlbIni]::Read($poIni,'pushover','user')
        if (-not $token -or -not $user) {
            $private = Join-Path $PSScriptRoot 'MLB-private.ini'
            $token = [MlbIni]::Read($private,'Notifications','fixedToken'); $user = [MlbIni]::Read($private,'Notifications','fixedUser')
        }
        if (-not $token -or -not $user) { return }
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $body = @{token=$token;user=$user;title=$Title;message=$Message;sound='siren'}
            Invoke-RestMethod -Uri 'https://api.pushover.net/1/messages.json' -Method Post -Body $body -TimeoutSec 20 | Out-Null
        } catch {}
    }
    function Invoke-LocalUpdate {
        $file = Join-Path $PSScriptRoot 'MLB-local-update.json'
        if (-not (Test-Path -LiteralPath $file)) { return }
        try { $pending = Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json } catch { return }
        if (-not (Test-LocalUpdatePending $pending (Get-MlbVersion))) { return }
        if (@(Get-Process -Name MLB -ErrorAction SilentlyContinue).Count -gt 0) { return }
        $ok = $false
        if ((Test-Path -LiteralPath $pending.python) -and (Test-Path -LiteralPath $pending.installer)) {
            Write-Host ('새 수정본 ' + $pending.version + ' 설치 중입니다. 1~2분 뒤 MLB가 켜집니다.')
            try {
                $proc = Start-Process -FilePath $pending.python -ArgumentList ('"' + $pending.installer + '"') -WorkingDirectory (Split-Path -Parent $pending.installer) -PassThru -Wait
                $ok = ($proc.ExitCode -eq 0) -and ((Get-MlbVersion) -eq [string]$pending.version)
            } catch { $ok = $false }
        }
        # Tried once either way, so a failing build never blocks every start.
        $pending | Add-Member -NotePropertyName done -NotePropertyValue $true -Force
        $pending | Add-Member -NotePropertyName installed -NotePropertyValue $ok -Force
        $pending | Add-Member -NotePropertyName tried_at -NotePropertyValue ((Get-Date).ToString('o')) -Force
        # A newer fix may have been dropped in while this one was installing: never overwrite it.
        try {
            $current = Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([string]$current.version -eq [string]$pending.version) { $pending | ConvertTo-Json | Set-Content -LiteralPath $file -Encoding UTF8 }
        } catch {}
        if ($ok) { Write-Host ('새 수정본 ' + $pending.version + ' 설치 완료') }
        else { Send-MlbPush 'MLB 수정본 설치 실패' ('수정본 ' + $pending.version + ' 설치가 검사에서 멈췄습니다. 기존 버전으로 실행합니다.') }
    }
    # A request left behind by a crash long ago must not trigger a surprise restart.
    if ((Test-Path -LiteralPath $requestIni) -and ((Get-Item -LiteralPath $requestIni).LastWriteTimeUtc -lt [DateTime]::UtcNow.AddMinutes(-10))) { Remove-Item -LiteralPath $requestIni -Force -ErrorAction SilentlyContinue }

    $exe = Join-Path $PSScriptRoot 'MLB.exe'
    $existing = @(Get-Process -Name MLB -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $exe } catch { $false } })
    if ($existing.Count -gt 0) { $target = $existing[0] }
    else {
        Invoke-LocalUpdate
        $target = Start-Process -FilePath $exe -ArgumentList '/Launched' -WorkingDirectory $PSScriptRoot -PassThru
    }
    Write-Host 'MLB recorder active. Keep this window open. Ctrl+C stops recording.'
    Write-Host '무한 모드 오류 시 자동 재시작(업데이트 후 재개)이 켜져 있습니다.'
    $seen = @{}
    $restartTriggered = $false
    $slot = 0
    $nextFrame = [datetime]::MinValue
    while ($true) {
        $target.Refresh()
        if ($target.HasExited) {
            $folder = Save-Incident $root $ring 'exit' "Exit code: $($target.ExitCode). Normal/manual exits are also recorded; this does not prove a crash." $target.Id -WithRecent:(Test-Path -LiteralPath $requestIni)
            try { Save-Screen (Join-Path $folder 'screen.png') } catch { $_ | Out-String | Add-Content (Join-Path $folder 'details.txt') }
            if (-not (Test-Path -LiteralPath $requestIni)) { break }
            # ---- auto restart: update, then relaunch and resume ----
            $reason = [MlbIni]::Read($requestIni,'Request','Reason')
            $kind = [MlbIni]::Read($requestIni,'Request','Kind')
            Remove-Item -LiteralPath $requestIni -Force -ErrorAction SilentlyContinue
            $nowUtc = [DateTime]::UtcNow
            $history = @(Get-History)
            $refusal = Test-RestartAllowed $history $kind $reason (Get-MlbVersion) $nowUtc
            if ($refusal) {
                $stopFolder = Save-Incident $root $ring 'autorestart-stopped' ("Refused: $refusal`r`nKind: $kind`r`nReason: $reason`r`nVersion: $(Get-MlbVersion)") $target.Id -WithRecent
                Send-MlbPush 'MLB 자동 재시작 중단' ("$refusal`n마지막 오류: $reason`nMLB를 직접 확인해주세요.")
                Write-Host ('자동 재시작 중단: ' + $refusal)
                break
            }
            $history += [pscustomobject]@{utc=$nowUtc.ToString('o');version=(Get-MlbVersion);kind=$kind;key=(Get-RestartKey $reason);planned=(Test-PlannedRestart $reason)}
            $history = @($history | Select-Object -Last 50)
            ConvertTo-Json -InputObject $history -Depth 3 | Set-Content -LiteralPath $historyFile -Encoding UTF8
            Write-Host ('자동 재시작: ' + $reason + ' → 업데이트 확인')
            $before = Get-MlbVersion
            Invoke-LocalUpdate
            $updater = Join-Path $PSScriptRoot 'MLB-updater.ps1'
            $updateExit = 0
            if (Test-Path -LiteralPath $updater) {
                & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $updater
                $updateExit = $LASTEXITCODE
            }
            if ($updateExit -ne 0) {
                # The updater exits non-zero only when its rollback failed; launching then is unsafe.
                Save-Incident $root $ring 'autorestart-stopped' "Updater failed with exit code $updateExit. Restore .update backup before launching." $target.Id | Out-Null
                Send-MlbPush 'MLB 자동 재시작 중단' '업데이트 복구 실패. MLB를 직접 확인해주세요.'
                break
            }
            $after = Get-MlbVersion
            if ($kind -eq 'dialog') { Send-MlbPush 'MLB 오류 자동 재시작' ("오류창 감지 → 종료 → 업데이트($before → $after) → 무한 재개`n$reason") }
            Start-Sleep -Seconds 2
            $target = Start-Process -FilePath $exe -ArgumentList '/InfiniteRestart' -WorkingDirectory $PSScriptRoot -PassThru
            $seen = @{}
            $restartTriggered = $false
            continue
        }
        if ((Get-Date) -ge $nextFrame) {
            try { Save-Screen (Join-Path $ring ('frame-{0:00}.jpg' -f $slot)) } catch { $_ | Out-String | Set-Content (Join-Path $root 'capture-failure.txt') }
            if ((Get-Date) -ge $nextCleanup) { Remove-OldIncidents $root 24 20; $nextCleanup = (Get-Date).AddHours(1) }
            $slot = ($slot + 1) % 12
            $nextFrame = (Get-Date).AddSeconds(10)
        }
        foreach ($windowText in [MlbWindows]::Read([uint32]$target.Id)) {
            if ((Test-ErrorText $windowText) -and -not $seen.ContainsKey($windowText)) {
                $folder = Save-Incident $root $ring 'dialog' $windowText $target.Id -WithRecent
                try { Save-Screen (Join-Path $folder 'screen.png') } catch { $_ | Out-String | Add-Content (Join-Path $folder 'details.txt') }
                $seen[$windowText] = $true
            }
        }
        if (-not $restartTriggered) {
            foreach ($dialogText in [MlbWindows]::ReadDialogs([uint32]$target.Id)) {
                if (-not (Test-ErrorText $dialogText)) { continue }
                # Only infinite mode has a verified resume path; its snapshot is refreshed every 10 s while it runs.
                if ([MlbIni]::Read($snapshotIni,'Restart','Job') -ne 'tribute11') { break }
                if (-not (Test-SnapshotFresh ([MlbIni]::Read($snapshotIni,'Restart','Updated')) ([DateTime]::UtcNow))) { break }
                $slave = 0; [void][int]::TryParse([MlbIni]::Read($snapshotIni,'Restart','Slave'),[ref]$slave)
                if ($slave -lt 1 -or $slave -gt 6) { break }
                $short = (($dialogText -replace '\s+',' ').Trim())
                if ($short.Length -gt 160) { $short = $short.Substring(0,160) }
                Copy-Item -LiteralPath $snapshotIni -Destination $stateIni -Force
                [void][MlbIni]::WritePrivateProfileString('Restart','Reason',('오류창 감지: ' + $short),$stateIni)
                Remove-Item -LiteralPath $requestIni -Force -ErrorAction SilentlyContinue
                [void][MlbIni]::WritePrivateProfileString('Request','Reason',$short,$requestIni)
                [void][MlbIni]::WritePrivateProfileString('Request','Kind','dialog',$requestIni)
                $restartTriggered = $true
                Write-Host ('오류창 감지 → MLB 종료 후 재시작: ' + $short)
                try { Stop-Process -Id $target.Id -Force } catch { $_ | Out-String | Add-Content (Join-Path $root 'recorder-failure.txt') }
                try { [void]$target.WaitForExit(15000) } catch {}
                break
            }
        }
        Start-Sleep -Milliseconds 500
    }
} catch {
    $_ | Out-String | Set-Content -LiteralPath (Join-Path $root 'recorder-failure.txt') -Encoding UTF8
    Write-Host $_
    Read-Host 'Recorder failed. Press Enter to close'
} finally {
    if ($supervisor) { $supervisor.Dispose() }
    $mutex.ReleaseMutex()
    $mutex.Dispose()
}
