﻿param([switch]$LibraryOnly)
$ErrorActionPreference = 'Stop'
# MLB 0.83-local.115 recorder + infinite-mode auto-restart supervisor.
# Recording behaviour is unchanged. Added: when infinite mode hits an error dialog or the
# MLB watchdog requests a restart, MLB is closed, the updater runs, and MLB is relaunched
# with /InfiniteRestart so the saved character/mode resumes. Loop guard stops repeated restarts.
function Test-ErrorText([string]$Text) {
    return $Text -match '(?i)\berror\b|\bexception\b|오류|에러|작동이 중지'
}



function Test-LocalUpdatePending($Pending, [string]$CurrentVersion) {
    # A fix prepared on this PC (MLB-local-update.json) is installed once, before MLB starts.
    if (-not $Pending -or $Pending.done) { return $false }
    if (-not $Pending.version -or -not $Pending.installer -or -not $Pending.python) { return $false }
    return ([string]$Pending.version -ne $CurrentVersion)
}
function Get-RestartKey([string]$Reason) {
    # Digits (minutes, counters, times) change between otherwise identical failures.
    return (($Reason -replace '\d+','#') -replace '\s+',' ').Trim()
}
function Test-PlannedRestart([string]$Reason) {
    return $Reason -match '판 완료'
}
function Test-RestartAllowed($History, [string]$Kind, [string]$Reason, [string]$Version, [datetime]$NowUtc) {
    # Returns '' when allowed, otherwise the reason the restart is refused.
    if (Test-PlannedRestart $Reason) { return '' }
    $window = $NowUtc.AddMinutes(-30)
    $recent = @($History | Where-Object { -not $_.planned -and [datetime]::Parse($_.utc).ToUniversalTime() -ge $window })
    if ($recent.Count -ge 3) { return '30분 안에 자동 재시작 3회 초과' }
    $last = @($History | Where-Object { -not $_.planned }) | Select-Object -Last 1
    if ($last -and [datetime]::Parse($last.utc).ToUniversalTime() -ge $window -and $last.version -eq $Version -and $last.key -eq (Get-RestartKey $Reason)) {
        return '같은 버전에서 같은 오류 2회 연속'
    }
    return ''
}
function Test-SnapshotFresh([string]$Updated, [datetime]$NowUtc, [int]$MaxSeconds = 90) {
    $parsed = [datetime]::MinValue
    if (-not [datetime]::TryParseExact($Updated,'yyyyMMddHHmmss',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]'AssumeUniversal,AdjustToUniversal',[ref]$parsed)) { return $false }
    $age = ($NowUtc - $parsed).TotalSeconds
    return ($age -ge -30 -and $age -le $MaxSeconds)
}
$script:RestartHistory = @()
function Get-History { return @($script:RestartHistory) }
if ($LibraryOnly) { return }

$identity = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $identity.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    # MLB.exe requires administrator rights. Elevating the recorder once lets it restart MLB without a UAC prompt each time.
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -WorkingDirectory $PSScriptRoot -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $PSCommandPath + '"')) | Out-Null
    } catch {
        Write-Host '관리자 권한이 거부되어 MLB를 시작하지 않았습니다. 다시 실행해 [예]를 눌러주세요.'
        Read-Host 'Enter를 누르면 닫힙니다'
    }
    exit
}

$mutex = New-Object Threading.Mutex($false, 'Local\MLB_Error_Recorder')
if (-not $mutex.WaitOne(0)) {
    Write-Host 'Recorder already running.'
    # MLB.exe hands its start to this script; never leave the user with nothing running.
    $mlbExe = Join-Path $PSScriptRoot 'MLB.exe'
    $running = @(Get-Process -Name MLB -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $mlbExe } catch { $true } })
    if ($running.Count -eq 0) { Start-Process -FilePath $mlbExe -ArgumentList '/Launched' -WorkingDirectory $PSScriptRoot | Out-Null }
    exit
}
$supervisor = $null
try {
    # MLB 0.83-local.75+ checks this name before handing its restart to the recorder.
    $supervisor = New-Object Threading.Mutex($false, 'Local\MLB_Restart_Supervisor')
    Add-Type -AssemblyName System.Windows.Forms, System.Drawing
    Add-Type @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class MlbWindows {
 public delegate bool Callback(IntPtr h, IntPtr l);
 [DllImport("user32.dll")] static extern bool EnumWindows(Callback cb, IntPtr l);
 [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr h, Callback cb, IntPtr l);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder b, int n);
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder b, int n);
 [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
 static string Text(IntPtr h) { var b=new StringBuilder(8192); GetWindowText(h,b,b.Capacity); return b.ToString(); }
 static string Cls(IntPtr h) { var b=new StringBuilder(256); GetClassName(h,b,b.Capacity); return b.ToString(); }
 static string[] Collect(uint pid, bool dialogsOnly) {
  var list=new List<string>();
  EnumWindows((h,l)=>{ uint p; GetWindowThreadProcessId(h,out p);
   if(p==pid && IsWindowVisible(h) && (!dialogsOnly || Cls(h)=="#32770")) { var b=new StringBuilder(Text(h));
    EnumChildWindows(h,(c,x)=>{b.AppendLine(Text(c)); return true;},IntPtr.Zero);
    list.Add(b.ToString()); } return true;},IntPtr.Zero);
  return list.ToArray();
 }
 public static string[] Read(uint pid) { return Collect(pid,false); }
 // Message boxes and AutoHotkey error dialogs only (class #32770); the MLB main window is excluded.
 public static string[] ReadDialogs(uint pid) { return Collect(pid,true); }
}
public class MlbRect {
 [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
 [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
 [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
 public static int[] Get(IntPtr h) { RECT r; if (h==IntPtr.Zero || IsIconic(h) || !GetWindowRect(h,out r)) return null; return new int[]{r.Left,r.Top,r.Right-r.Left,r.Bottom-r.Top}; }
}
public class MlbIni {
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern uint GetPrivateProfileString(string s, string k, string d, StringBuilder r, uint n, string f);
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] public static extern bool WritePrivateProfileString(string s, string k, string v, string f);
 public static string Read(string f, string s, string k) { var b=new StringBuilder(4096); GetPrivateProfileString(s,k,"",b,(uint)b.Capacity,f); return b.ToString(); }
}
'@
    [void][MlbWindows]::SetProcessDPIAware()

    # Old PNG frames from earlier versions and records older than 3 days are cleared at start, then hourly.
    $temp = [IO.Path]::GetTempPath()
    $stateIni = Join-Path $temp 'MLB_InfiniteRestart_MLB.exe.ini'
    $snapshotIni = Join-Path $temp 'MLB_InfiniteResume_MLB.exe.ini'
    $requestIni = Join-Path $temp 'MLB_RestartRequest_MLB.exe.ini'
    function Get-MlbVersion { try { return (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'version.txt') -Raw).Trim() } catch { return 'unknown' } }

    function Send-MlbPush([string]$Title, [string]$Message) {
        # Same Pushover account MLB already uses (MLB settings first, then the private defaults).
        $poIni = Join-Path $temp 'MabiMacros\pushover.ini'
        $token = [MlbIni]::Read($poIni,'pushover','token'); $user = [MlbIni]::Read($poIni,'pushover','user')
        if (-not $token -or -not $user) {
            $private = Join-Path $PSScriptRoot 'MLB-private.ini'
            $token = [MlbIni]::Read($private,'Notifications','fixedToken'); $user = [MlbIni]::Read($private,'Notifications','fixedUser')
        }
        if (-not $token -or -not $user) { return }
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $body = @{token=$token;user=$user;title=$Title;message=$Message;sound='siren'}
            Invoke-RestMethod -Uri 'https://api.pushover.net/1/messages.json' -Method Post -Body $body -TimeoutSec 20 | Out-Null
        } catch {}
    }
    function Invoke-LocalUpdate {
        $file = Join-Path $PSScriptRoot 'MLB-local-update.json'
        if (-not (Test-Path -LiteralPath $file)) { return }
        try { $pending = Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json } catch { return }
        if (-not (Test-LocalUpdatePending $pending (Get-MlbVersion))) { return }
        if (@(Get-Process -Name MLB -ErrorAction SilentlyContinue).Count -gt 0) { return }
        $ok = $false
        if ((Test-Path -LiteralPath $pending.python) -and (Test-Path -LiteralPath $pending.installer)) {
            Write-Host ('새 수정본 ' + $pending.version + ' 설치 중입니다. 1~2분 뒤 MLB가 켜집니다.')
            try {
                $proc = Start-Process -FilePath $pending.python -ArgumentList ('"' + $pending.installer + '"') -WorkingDirectory (Split-Path -Parent $pending.installer) -PassThru -Wait
                $ok = ($proc.ExitCode -eq 0) -and ((Get-MlbVersion) -eq [string]$pending.version)
            } catch { $ok = $false }
        }
        # Tried once either way, so a failing build never blocks every start.
        $pending | Add-Member -NotePropertyName done -NotePropertyValue $true -Force
        $pending | Add-Member -NotePropertyName installed -NotePropertyValue $ok -Force
        $pending | Add-Member -NotePropertyName tried_at -NotePropertyValue ((Get-Date).ToString('o')) -Force
        # A newer fix may have been dropped in while this one was installing: never overwrite it.
        try {
            $current = Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([string]$current.version -eq [string]$pending.version) { $pending | ConvertTo-Json | Set-Content -LiteralPath $file -Encoding UTF8 }
        } catch {}
        if ($ok) { Write-Host ('새 수정본 ' + $pending.version + ' 설치 완료') }
        else { Send-MlbPush 'MLB 수정본 설치 실패' ('수정본 ' + $pending.version + ' 설치가 검사에서 멈췄습니다. 기존 버전으로 실행합니다.') }
    }
    # A request left behind by a crash long ago must not trigger a surprise restart.
    if ((Test-Path -LiteralPath $requestIni) -and ((Get-Item -LiteralPath $requestIni).LastWriteTimeUtc -lt [DateTime]::UtcNow.AddMinutes(-10))) { Remove-Item -LiteralPath $requestIni -Force -ErrorAction SilentlyContinue }

    $exe = Join-Path $PSScriptRoot 'MLB.exe'
    $existing = @(Get-Process -Name MLB -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $exe } catch { $false } })
    if ($existing.Count -gt 0) { $target = $existing[0] }
    else {
        Invoke-LocalUpdate
        $target = Start-Process -FilePath $exe -ArgumentList '/Launched' -WorkingDirectory $PSScriptRoot -PassThru
    }
    Write-Host 'MLB supervisor active. Disk diagnostic recording is disabled. Keep this window open.'
    Write-Host '무한 모드 오류 시 자동 재시작(업데이트 후 재개)이 켜져 있습니다.'
    $seen = @{}
    $restartTriggered = $false
    while ($true) {
        $target.Refresh()
        if ($target.HasExited) {
            if (-not (Test-Path -LiteralPath $requestIni)) { break }
            # ---- auto restart: update, then relaunch and resume ----
            $reason = [MlbIni]::Read($requestIni,'Request','Reason')
            $kind = [MlbIni]::Read($requestIni,'Request','Kind')
            Remove-Item -LiteralPath $requestIni -Force -ErrorAction SilentlyContinue
            $nowUtc = [DateTime]::UtcNow
            $history = @(Get-History)
            $refusal = Test-RestartAllowed $history $kind $reason (Get-MlbVersion) $nowUtc
            if ($refusal) {
                Send-MlbPush 'MLB 자동 재시작 중단' ("$refusal`n마지막 오류: $reason`nMLB를 직접 확인해주세요.")
                Write-Host ('자동 재시작 중단: ' + $refusal)
                break
            }
            $history += [pscustomobject]@{utc=$nowUtc.ToString('o');version=(Get-MlbVersion);kind=$kind;key=(Get-RestartKey $reason);planned=(Test-PlannedRestart $reason)}
            $history = @($history | Select-Object -Last 50)
            $script:RestartHistory = $history
            Write-Host ('자동 재시작: ' + $reason + ' → 업데이트 확인')
            $before = Get-MlbVersion
            Invoke-LocalUpdate
            $updater = Join-Path $PSScriptRoot 'MLB-updater.ps1'
            $updateExit = 0
            if (Test-Path -LiteralPath $updater) {
                & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $updater
                $updateExit = $LASTEXITCODE
            }
            if ($updateExit -ne 0) {
                # The updater exits non-zero only when its rollback failed; launching then is unsafe.
                Send-MlbPush 'MLB 자동 재시작 중단' '업데이트 복구 실패. MLB를 직접 확인해주세요.'
                break
            }
            $after = Get-MlbVersion
            if ($kind -eq 'dialog') { Send-MlbPush 'MLB 오류 자동 재시작' ("오류창 감지 → 종료 → 업데이트($before → $after) → 무한 재개`n$reason") }
            Start-Sleep -Seconds 2
            $target = Start-Process -FilePath $exe -ArgumentList '/InfiniteRestart' -WorkingDirectory $PSScriptRoot -PassThru
            $seen = @{}
            $restartTriggered = $false
            continue
        }

        foreach ($windowText in [MlbWindows]::Read([uint32]$target.Id)) {
            if ((Test-ErrorText $windowText) -and -not $seen.ContainsKey($windowText)) {
                $seen[$windowText] = $true
            }
        }
        if (-not $restartTriggered) {
            foreach ($dialogText in [MlbWindows]::ReadDialogs([uint32]$target.Id)) {
                if (-not (Test-ErrorText $dialogText)) { continue }
                # Only infinite mode has a verified resume path; its snapshot is refreshed every 10 s while it runs.
                if ([MlbIni]::Read($snapshotIni,'Restart','Job') -ne 'tribute11') { break }
                if (-not (Test-SnapshotFresh ([MlbIni]::Read($snapshotIni,'Restart','Updated')) ([DateTime]::UtcNow))) { break }
                $slave = 0; [void][int]::TryParse([MlbIni]::Read($snapshotIni,'Restart','Slave'),[ref]$slave)
                if ($slave -lt 1 -or $slave -gt 6) { break }
                $short = (($dialogText -replace '\s+',' ').Trim())
                if ($short.Length -gt 160) { $short = $short.Substring(0,160) }
                Copy-Item -LiteralPath $snapshotIni -Destination $stateIni -Force
                [void][MlbIni]::WritePrivateProfileString('Restart','Reason',('오류창 감지: ' + $short),$stateIni)
                Remove-Item -LiteralPath $requestIni -Force -ErrorAction SilentlyContinue
                [void][MlbIni]::WritePrivateProfileString('Request','Reason',$short,$requestIni)
                [void][MlbIni]::WritePrivateProfileString('Request','Kind','dialog',$requestIni)
                $restartTriggered = $true
                Write-Host ('오류창 감지 → MLB 종료 후 재시작: ' + $short)
                try { Stop-Process -Id $target.Id -Force } catch { Write-Host $_ }
                try { [void]$target.WaitForExit(15000) } catch {}
                break
            }
        }
        Start-Sleep -Milliseconds 500
    }
} catch {
    Write-Host $_
    Read-Host 'Recorder failed. Press Enter to close'
} finally {
    if ($supervisor) { $supervisor.Dispose() }
    $mutex.ReleaseMutex()
    $mutex.Dispose()
}
